# main.py
from student import Student
from group import Group
from exceptions import GroupFullException


def main():
    st1 = Student('Male', 30, 'Steve', 'Jobs', 'AN142')
    st2 = Student('Female', 25, 'Liza', 'Taylor', 'AN145')
    gr = Group('PD1')
    gr.add_student(st1)
    gr.add_student(st2)
    print(gr)

    assert gr.find_student('Jobs') == st1, 'Test1'
    assert gr.find_student('Jobs2') is None, 'Test2'
    assert isinstance(gr.find_student('Jobs'), Student), 'Метод поиска должен возвращать экземпляр'

    gr.delete_student('Taylor')
    print(gr)  # Only one student

    gr.delete_student('Taylor')  # No error!

    students_to_add = [
        Student('Male', 30, 'Ernest', 'Hemingway', 'AN142'),
        Student('Male', 25, 'Ken', 'Kesey', 'AN145'),
        Student('Male', 22, 'Mark', 'Twain', 'AN11'),
        Student('Female', 23, 'Emily', 'Dickinson', 'AN12'),
        Student('Male', 24, 'F. Scott', 'Fitzgerald', 'AN13'),
        Student('Male', 21, 'J.D.', 'Salinger', 'AN14'),
        Student('Male', 26, 'Stephen', 'King', 'AN15'),
        Student('Male', 27, 'O.', 'Henry', 'AN16'),
        Student('Male', 28, 'Charles', 'Dickens', 'AN17'),
        Student('Female', 29, 'Flannery', "O'Connor", 'AN18'),
        Student('Male', 20, 'Jack', 'Kerouac', 'AN19')
    ]

    gr = Group('PD1')
    for student in students_to_add:
        try:
            gr.add_student(student)
            print(f"Студент {student.first_name} {student.last_name} успішно доданий.")
        except GroupFullException as e:
            print(f"Виняток при додаванні студента {student.first_name} {student.last_name}: {e}")

    print(gr)


if __name__ == "__main__":
    main()
