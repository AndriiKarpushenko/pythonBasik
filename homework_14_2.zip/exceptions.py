# exceptions.py
class GroupFullException(Exception):
    def __init__(self, message="Додано більше 10-ти студентів"):
        self.message = message
        Exception.__init__(self, self.message)
